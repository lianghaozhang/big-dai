package com.fuchenkai.Note;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.fuchenkai.Note.fragment.One;
import com.fuchenkai.Note.fragment.Two;


public class MainActivity extends AppCompatActivity {
    private static FragmentManager fragmentManager;
    private static One one;
    private static Two two;
    public static int sign = 0;
    public static MyNote myNote;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragmentManager = getSupportFragmentManager();

        setChioceItem(0); // 初始化页面加载时显示第一个选项卡
    }

    @SuppressLint("ResourceAsColor")
    private static void setChioceItem(final int index) {
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        hideFragments(fragmentTransaction);
        switch (index) {
            case 0:
                if (one == null) {
                    one = new One();
                    fragmentTransaction.add(R.id.content, one);
                }
                else {
                    fragmentTransaction.show(one);
                    one.onResume();
                }

                break;
            case 1:
                if (two == null) {
                    two = new Two();
                    fragmentTransaction.add(R.id.content, two);
                } else {
                    fragmentTransaction.show(two);
                    two.onResume();
                }
                break;
        }
        fragmentTransaction.commit();
    }
    private static void hideFragments(FragmentTransaction fragmentTransaction) {
        if (one != null) {
            fragmentTransaction.hide(one);
        }
        if (two!= null) {
            fragmentTransaction.hide(two);
        }

    }
    public static void setview(int n){
        setChioceItem(n);
    }
}