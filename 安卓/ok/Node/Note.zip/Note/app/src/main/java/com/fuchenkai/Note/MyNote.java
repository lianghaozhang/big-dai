package com.fuchenkai.Note;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "mynote")
public class MyNote {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id",typeAffinity = ColumnInfo.INTEGER)
    public int id;

    @ColumnInfo(name = "title",typeAffinity = ColumnInfo.TEXT)
    public  String title;

    @ColumnInfo(name= "time",typeAffinity = ColumnInfo.TEXT)
    public  String time;

    @ColumnInfo(name= "locate",typeAffinity = ColumnInfo.TEXT)
    public  String locate;

    @ColumnInfo(name= "content",typeAffinity = ColumnInfo.TEXT)
    public  String content;

    public MyNote(int id, String title, String time, String locate, String content) {
        this.id = id;
        this.title = title;
        this.time = time;
        this.locate = locate;
        this.content = content;
    }
    @Ignore
    public MyNote(String title, String time, String locate, String content) {
        this.title = title;
        this.time = time;
        this.locate = locate;
        this.content = content;
    }
    @Ignore
    public MyNote(int id) {
        this.id = id;
    }
}
