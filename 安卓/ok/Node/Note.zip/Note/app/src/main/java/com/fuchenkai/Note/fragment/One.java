package com.fuchenkai.Note.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.fuchenkai.Note.MainActivity;
import com.fuchenkai.Note.MyDatabase;
import com.fuchenkai.Note.MyNote;
import com.fuchenkai.Note.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class One extends Fragment {
    private View view;
    ListView listView;
    private Button add;
    private List<Map<String, Object>> data;
    private List<MyNote> list;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.one, container, false);

        setListView();
        add = view.findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.sign=0;
                MainActivity.setview(1);
            }
        });
        return view;
    }

//    private void setListView() {
//        listView =view.findViewById(R.id.listView);
//        MyDatabase myDatabase = MyDatabase.getInstance(getContext());
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                list = myDatabase.myNoteDao().getMyNoteList();
//                if(list!=null){
//                    data = new ArrayList<>();
//                    for (int i = 0; i < list.size(); i++) {
//                        Map<String, Object> map = new HashMap<String, Object>();
//                        map.put("title",list.get(i).title);
//                        map.put("time", list.get(i).time);
//                        data.add(map);
//                    }
//                    SimpleAdapter simpleAdapter = new SimpleAdapter(getContext(),
//                            data,
//                            R.layout.item,
//                            new String[]{"title", "time"},
//                            new int[]{R.id.item_title, R.id.item_time});
//                    listView.setAdapter(simpleAdapter);
//                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                        @Override
//                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                            MainActivity.myNote = list.get(position);
//                            MainActivity.sign=1;
//                            MainActivity.setview(1);
//                        }
//                    });
//                }
//            }
//        }).start();
//    }


    private void setListView() {
        listView = view.findViewById(R.id.listView);
        MyDatabase myDatabase = MyDatabase.getInstance(getContext());
        new Thread(new Runnable() {
            @Override
            public void run() {
                list = myDatabase.myNoteDao().getMyNoteList();
                if (list != null) {
                    data = new ArrayList<>();
                    for (int i = 0; i < list.size(); i++) {
                        Map<String, Object> map = new HashMap<String, Object>();
                        map.put("title", list.get(i).title);
                        map.put("time", list.get(i).time);
                        data.add(map);
                    }

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            SimpleAdapter simpleAdapter = new SimpleAdapter(getContext(),
                                    data,
                                    R.layout.item,
                                    new String[]{"title", "time"},
                                    new int[]{R.id.item_title, R.id.item_time});
                            listView.setAdapter(simpleAdapter);

                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    MainActivity.myNote = list.get(position);
                                    MainActivity.sign = 1;
                                    MainActivity.setview(1);
                                }
                            });
                        }
                    });
                }
            }
        }).start();
    }



    @Override
    public void onResume() {
        super.onResume();
        setListView();
    }
}