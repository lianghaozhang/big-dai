package com.fuchenkai.Note.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.fuchenkai.Note.MainActivity;
import com.fuchenkai.Note.MyDatabase;
import com.fuchenkai.Note.MyNote;
import com.fuchenkai.Note.R;

import java.util.Calendar;


public class Two extends Fragment {
    private View view;
    private EditText title,locate,content;
    private Button submit,back,del;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.two, container, false);
        initView();
        setView();
        return view;
    }

    private void initView() {

        title = view.findViewById(R.id.edit1);
        locate = view.findViewById(R.id.edit2);
        content= view.findViewById(R.id.edit3);
        submit = view.findViewById(R.id.submit);
        back = view.findViewById(R.id.back);
        del = view.findViewById(R.id.del);
    }

    private void setView() {
        if(MainActivity.sign==1){
            title.setText(MainActivity.myNote.title);
            locate.setText(MainActivity.myNote.locate);
            content.setText(MainActivity.myNote.content);
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder2 = new AlertDialog.Builder(getContext());
                    builder2.setTitle("删除");
                    builder2.setMessage("您确定要删除吗？");
                    builder2.setPositiveButton("确认", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    MyDatabase myDatabase = MyDatabase.getInstance(getContext());
                                    myDatabase.myNoteDao().deleteMyNote(new MyNote(MainActivity.myNote.id));
                                    MainActivity.setview(0);
                                    Looper.prepare();
                                    Toast.makeText(getContext(), "删除成功！", Toast.LENGTH_SHORT).show();
                                    Looper.loop();

                                }
                            }).start();
                        }
                    });
                    builder2.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    builder2.show();
                }
            });
        }
        else {
            title.setText("");
            locate.setText("");
            content.setText("");

        }
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(title.getText().toString().equals("")||
                        locate.getText().toString().equals("")||
                        content.getText().toString().equals("")){
                    Toast.makeText(getContext(), "有输入为空，请检查输入！", Toast.LENGTH_SHORT).show();
                }
                else {
                    MyDatabase myDatabase = MyDatabase.getInstance(getContext());
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                                Calendar calendar= Calendar.getInstance();
                                SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                                myDatabase.myNoteDao().insertMyNote(new MyNote(title.getText().toString(),
                                        dateFormat.format(calendar.getTime()),
                                        locate.getText().toString(),
                                        content.getText().toString()));
                                MainActivity.setview(0);
                                Looper.prepare();
                                Toast.makeText(getContext(), "添加成功！", Toast.LENGTH_SHORT).show();
                                Looper.loop();

                        }
                    }).start();

                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.setview(0);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        setView();
    }
}
