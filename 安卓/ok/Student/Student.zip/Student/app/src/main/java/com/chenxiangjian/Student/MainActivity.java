package com.chenxiangjian.Student;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.chenxiangjian.Student.fragment.List;
import com.chenxiangjian.Student.fragment.Add;

public class MainActivity extends AppCompatActivity {
    private static FragmentManager fragmentManager;
    @SuppressLint("StaticFieldLeak")
    private static List list;
    @SuppressLint("StaticFieldLeak")
    private static Add add;
    public static int sign = 0;
    public static Students students;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragmentManager = getSupportFragmentManager();
        setChioceItem(0);
    }

    @SuppressLint("ResourceAsColor")
    private static void setChioceItem(final int index) {
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        hideFragments(fragmentTransaction);
        switch (index) {
            case 0:
                if (list == null) {
                    list = new List();
                    fragmentTransaction.add(R.id.content, list);
                }
                else {
                    fragmentTransaction.show(list);
                    list.onResume();
                }

                break;
            case 1:
                if (add == null) {
                    add = new Add();
                    fragmentTransaction.add(R.id.content, add);
                } else {
                    fragmentTransaction.show(add);
                    add.onResume();
                }
                break;
        }
        fragmentTransaction.commit();
    }
    private static void hideFragments(FragmentTransaction fragmentTransaction) {
        if (list != null) {
            fragmentTransaction.hide(list);
        }
        if (add != null) {
            fragmentTransaction.hide(add);
        }
    }
    public static void setview(int n){
        setChioceItem(n);
    }
}