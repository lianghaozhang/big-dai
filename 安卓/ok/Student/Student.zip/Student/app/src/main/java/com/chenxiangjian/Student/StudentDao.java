package com.chenxiangjian.Student;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface StudentDao {
    @Insert
    void insertStudent(Students student);
    @Update
    void updateStudent(Students student);
    @Query("SELECT * FROM students")
    List<Students> getStudentList();
    @Query("SELECT * FROM students WHERE id = :id")
    Students getStudentById(int id);

}
