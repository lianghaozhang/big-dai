package com.chenxiangjian.Student;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "students")
public class   Students {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id",typeAffinity = ColumnInfo.INTEGER)
    public int id;

    @ColumnInfo(name = "name",typeAffinity = ColumnInfo.TEXT)
    public  String name;

    @ColumnInfo(name= "age",typeAffinity = ColumnInfo.TEXT)
    public  String age;

    @ColumnInfo(name= "sex",typeAffinity = ColumnInfo.TEXT)
    public  String sex;

    @ColumnInfo(name= "phone",typeAffinity = ColumnInfo.TEXT)
    public  String phone;

    @ColumnInfo(name= "introduction",typeAffinity = ColumnInfo.TEXT)
    public  String introduction;

    //Room默认会使用这个构造器操作数据
    public Students(int id, String name, String age, String sex, String phone, String introduction) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.sex = sex;
        this.phone = phone;
        this.introduction = introduction;
    }

    @Ignore
    public Students(int id, String name, String age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }
    @Ignore
    public  Students(String name,String age){
        this.name = name;
        this.age= age;
    }
    @Ignore
    public Students(int id) {
        this.id = id;
    }
}

