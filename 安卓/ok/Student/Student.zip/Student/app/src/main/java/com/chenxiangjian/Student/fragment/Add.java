package com.chenxiangjian.Student.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.fragment.app.Fragment;

import com.chenxiangjian.Student.MainActivity;
import com.chenxiangjian.Student.MyDatabase;
import com.chenxiangjian.Student.R;
import com.chenxiangjian.Student.Students;


public class Add extends Fragment {
    private View view;
    String sex="男";
    private RadioGroup radioGroup;
    private RadioButton radioButton,radioButton2;
    private EditText id,name,age,phone,introduction;
    private Button submit;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.add, container, false);
        initView();
        setRadioGroup();
        setView();
        return view;
    }

    private void initView() {
        Toolbar toolBar = view.findViewById(R.id.toolbar);
        toolBar.setTitle("返回");//设置主标题名称
        toolBar.setNavigationIcon(R.drawable.back);
        toolBar.setNavigationOnClickListener(view -> MainActivity.setview(0));
        radioGroup=view.findViewById(R.id.radioGroup);
        radioButton= view.findViewById(R.id.sexMale);
        radioButton2 =view.findViewById(R.id.sexFemale);
        radioButton.setChecked(true);
        id = view.findViewById(R.id.edit1);
        name = view.findViewById(R.id.edit2);
        age= view.findViewById(R.id.edit3);
        phone= view.findViewById(R.id.edit4);
        introduction= view.findViewById(R.id.edit5);
        submit = view.findViewById(R.id.submit);


    }
    private void setRadioGroup() {
        radioGroup.setOnCheckedChangeListener((radioGroup, i) -> {
            RadioButton radioButton=view.findViewById(i);
            sex = radioButton.getText().toString();
        });
    }
    @SuppressLint("SetTextI18n")
    private void setView() {
        if(MainActivity.sign==1){
            id.setText(MainActivity.students.id+"");
            name.setText(MainActivity.students.name);
            age.setText(MainActivity.students.age);
            phone.setText(MainActivity.students.phone);
            introduction.setText(MainActivity.students.introduction);
            sex=MainActivity.students.sex;
            if(MainActivity.students.sex.equals("男")){
                radioButton.setChecked(true);
                radioButton2.setChecked(false);
            }
            else{
                radioButton.setChecked(false);
                radioButton2.setChecked(true);
            }

        }
        else {
            id.setText("");
            name.setText("");
            age.setText("");
            phone.setText("");
            introduction.setText("");
            radioButton.setChecked(true);
        }
        submit.setOnClickListener(v -> {
            if(id.getText().toString().isEmpty() ||
                    name.getText().toString().isEmpty() ||
                    age.getText().toString().isEmpty() ||
                    phone.getText().toString().isEmpty() ||
                    introduction.getText().toString().isEmpty()){
                Toast.makeText(getContext(), "有输入为空，请检查输入！", Toast.LENGTH_SHORT).show();
            }
            else {
                MyDatabase myDatabase = MyDatabase.getInstance(getContext());
                new Thread(() -> {
                    if(MainActivity.sign==0){
                        Students students =  myDatabase.studentDao().getStudentById(Integer.parseInt(id.getText().toString()));
                        if(students!=null){
                            Looper.prepare();
                            Toast.makeText(getContext(), "学号重复！", Toast.LENGTH_SHORT).show();
                            Looper.loop();
                        }
                        else {
                            myDatabase.studentDao().insertStudent(new Students(Integer.parseInt(id.getText().toString()),
                                    name.getText().toString() ,
                                    age.getText().toString(),
                                    sex,phone.getText().toString(),
                                    introduction.getText().toString()));
                            MainActivity.setview(0);
                            Looper.prepare();
                            Toast.makeText(getContext(), "添加成功！", Toast.LENGTH_SHORT).show();
                            Looper.loop();

                        }
                    }
                    else {
                        myDatabase.studentDao().updateStudent(new Students(Integer.parseInt(id.getText().toString()),
                                name.getText().toString() ,
                                age.getText().toString(),
                                sex,phone.getText().toString(),
                                introduction.getText().toString()));
                        MainActivity.setview(0);
                        Looper.prepare();
                        Toast.makeText(getContext(), "修改成功！", Toast.LENGTH_SHORT).show();
                        Looper.loop();
                    }

                }).start();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        setView();
    }
}
