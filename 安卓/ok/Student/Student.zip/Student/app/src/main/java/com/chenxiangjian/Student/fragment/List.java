package com.chenxiangjian.Student.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.fragment.app.Fragment;

import com.chenxiangjian.Student.MainActivity;
import com.chenxiangjian.Student.MyDatabase;
import com.chenxiangjian.Student.R;
import com.chenxiangjian.Student.Students;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class List extends Fragment {
    private View view;
    private ListView listView;
    private java.util.List<Map<String, Object>> data;
    private java.util.List<Students> list;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.list, container, false);
        Button add = view.findViewById(R.id.add);
        add.setOnClickListener(v -> {
            MainActivity.sign=0;
            MainActivity.setview(1);
        });
        setListView();
        return view;
    }

    private void setListView() {
        listView = view.findViewById(R.id.listView);
        MyDatabase myDatabase = MyDatabase.getInstance(getContext());
        new Thread(() -> {
            list = myDatabase.studentDao().getStudentList();
            if (list != null) {
                data = new ArrayList<>();
                for (int i = 0; i < list.size(); i++) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("sum", i + 1);
                    map.put("id", list.get(i).id);
                    map.put("name", list.get(i).name);
                    data.add(map);
                }

                getActivity().runOnUiThread(() -> {
                    SimpleAdapter simpleAdapter = new SimpleAdapter(getContext(),
                            data,
                            R.layout.item,
                            new String[]{"sum", "id", "name"},
                            new int[]{R.id.item_sum, R.id.item_id, R.id.item_name});
                    listView.setAdapter(simpleAdapter);
                    listView.setOnItemClickListener((parent, view, position, id) -> {
                        MainActivity.students = list.get(position);
                        MainActivity.sign = 1;
                        MainActivity.setview(1);
                    });
                });
            }
        }).start();
    }


    @Override
    public void onResume() {
        super.onResume();
        setListView();
    }
}