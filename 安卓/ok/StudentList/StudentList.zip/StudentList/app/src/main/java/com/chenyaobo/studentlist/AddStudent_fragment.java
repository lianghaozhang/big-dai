package com.chenyaobo.studentlist;

import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;


public class AddStudent_fragment extends Fragment {
    private View view;
    String sex="男";
    private RadioGroup radioGroup;
    private RadioButton radioButton,radioButton2;
    private EditText id,name,age,phone,introduction;
    private Button submit,back;
    int age_num;
    private ImageButton up,down;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.addstudent, container, false);
        initView();
        setRadioGroup();
        setView();
        return view;
    }

    private void initView() {
        radioGroup=view.findViewById(R.id.radioGroup);
        radioButton= view.findViewById(R.id.sexMale);
        radioButton2 =view.findViewById(R.id.sexFemale);
        radioButton.setChecked(true);
        id = view.findViewById(R.id.edit1);
        name = view.findViewById(R.id.edit2);
        age= view.findViewById(R.id.edit3);
        phone= view.findViewById(R.id.edit4);
        introduction= view.findViewById(R.id.edit5);
        submit = view.findViewById(R.id.submit);
        back = view.findViewById(R.id.back);
        up = view.findViewById(R.id.up);
        down =view.findViewById(R.id.down);
    }

    private void setRadioGroup() {
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton radioButton=view.findViewById(i);
                sex = radioButton.getText().toString();
            }
        });
    }

    private void setView() {
        if(MainActivity_fragment.sign==1){
            age_num= Integer.parseInt(MainActivity_fragment.students.age);
            id.setText(MainActivity_fragment.students.id + "");
            name.setText(MainActivity_fragment.students.name);
            age.setText(MainActivity_fragment.students.age);
            phone.setText(MainActivity_fragment.students.phone);
            introduction.setText(MainActivity_fragment.students.introduction);
            sex= MainActivity_fragment.students.sex;
            if(MainActivity_fragment.students.sex.equals("男")){
                radioButton.setChecked(true);
                radioButton2.setChecked(false);
            }
            else{
                radioButton.setChecked(false);
                radioButton2.setChecked(true);
            }
        }
        else {
            age_num=20;
            id.setText("");
            name.setText("");
            age.setText(age_num+"");
            phone.setText("");
            introduction.setText("");
            radioButton.setChecked(true);
        }
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                age_num++;
                age.setText(""+age_num);
            }
        });
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(age_num>=2){
                    age_num--;
                    age.setText(""+age_num);
                }
                else
                    Toast.makeText(getContext(),"年龄不能小于1",Toast.LENGTH_SHORT).show();

            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(id.getText().toString().equals("")||
                        name.getText().toString().equals("")||
                        age.getText().toString().equals("")||
                        phone.getText().toString().equals("")||
                        introduction.getText().toString().equals("")){
                    Toast.makeText(getContext(), "有输入为空，请检查输入！", Toast.LENGTH_SHORT).show();
                }
                else {
                    MyDatabase myDatabase = MyDatabase.getInstance(getContext());
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            //id, String name, String age, String sex, String phone, String introduction
                            if(MainActivity_fragment.sign==0){
                                Students students =  myDatabase.studentDao().getStudentById(Integer.valueOf(id.getText().toString()));
                                if(students!=null){
                                    Looper.prepare();
                                    Toast.makeText(getContext(), "学号重复！", Toast.LENGTH_SHORT).show();
                                    Looper.loop();
                                }
                                else {
                                    myDatabase.studentDao().insert(new Students(Integer.valueOf(id.getText().toString()),
                                            name.getText().toString() ,
                                            age.getText().toString(),
                                            sex,phone.getText().toString(),
                                            introduction.getText().toString()));
                                    MainActivity_fragment.setview(0);
                                    Looper.prepare();
                                    Toast.makeText(getContext(), "添加成功！", Toast.LENGTH_SHORT).show();
                                    Looper.loop();

                                }
                            }
                            else {
                                myDatabase.studentDao().update(new Students(Integer.valueOf(id.getText().toString()),
                                        name.getText().toString() ,
                                        age.getText().toString(),
                                        sex,phone.getText().toString(),
                                        introduction.getText().toString()));
                                MainActivity_fragment.setview(0);
                                Looper.prepare();
                                Toast.makeText(getContext(), "修改成功！", Toast.LENGTH_SHORT).show();
                                Looper.loop();

                            }

                        }
                    }).start();

                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity_fragment.setview(0);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        setView();
    }
}
