package com.chenyaobo.studentlist;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity_fragment extends AppCompatActivity {
    private static FragmentManager fragmentManager;
    private static ShowStudentList showStudentList;
    private static AddStudent_fragment addStudentFragment;
    public static int sign = 0;
    public static Students students;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragmentManager = getSupportFragmentManager();
        setChioceItem(0);
    }

    private void initView() {}

    private static void setChioceItem(final int index) {
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        hideFragments(fragmentTransaction);
        switch (index) {
            case 0:
                if (showStudentList == null) {
                    showStudentList = new ShowStudentList();
                    fragmentTransaction.add(R.id.content, showStudentList);
                }
                else {
                    fragmentTransaction.show(showStudentList);
                    showStudentList.onResume();
                }

                break;
            case 1:
                if (addStudentFragment == null) {
                    addStudentFragment = new AddStudent_fragment();
                    fragmentTransaction.add(R.id.content, addStudentFragment);
                } else {
                    fragmentTransaction.show(addStudentFragment);
                    addStudentFragment.onResume();
                }
                break;
        }
        fragmentTransaction.commit();
    }
    private static void hideFragments(FragmentTransaction fragmentTransaction) {
        if (showStudentList != null) {
            fragmentTransaction.hide(showStudentList);
        }
        if (addStudentFragment != null) {
            fragmentTransaction.hide(addStudentFragment);
        }

    }
    public static void setview(int n){
        setChioceItem(n);
    }
}