package com.chenyaobo.studentlist;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface StudentDao {
    @Insert
    void insert(Students student);

    @Update
    void update(Students student);

    @Query("SELECT * FROM students")
    List<Students> getAll();

    @Query("SELECT * FROM students WHERE id = :id")
    Students getStudentById(int id);

}
