package com.daikailun.test;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.fragment.app.Fragment;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShowStudentList extends Fragment {
    private Activity mActivity;
    private Context mContext;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActivity = (Activity) context;
    }
    @Override
    public void onDetach() {
        super.onDetach();
        mActivity = null;
    }

    private View view;
    TextView textView;
    private ListView listView;
    private Button add;
    private List<Map<String, Object>> data;
    private List<Students> list;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.showstudentlist, container, false);
        add = view.findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity_fragment.sign=0;
                MainActivity_fragment.setview(1);
            }
        });
        setListView();
        return view;
    }


    private void setListView() {
        listView = view.findViewById(R.id.listView);
        MyDatabase myDatabase = MyDatabase.getInstance(mActivity);
        new Thread(new Runnable() {
            @Override
            public void run() {
                list = myDatabase.studentDao().getAll();
                if (list != null) {
                    data = new ArrayList<>();
                    for (int i = 0; i < list.size(); i++) {
                        Map<String, Object> map = new HashMap<>();
                        map.put("id", "学号：" + list.get(i).id);
                        map.put("name", "姓名：" + list.get(i).name);
                        data.add(map);
                    }

                    // 使用Handler将更新UI的操作传递给UI线程处理
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            SimpleAdapter simpleAdapter = new SimpleAdapter(mActivity, data, R.layout.item, new String[]{"id", "name"}, new int[]{R.id.item_id, R.id.item_name});
                            listView.setAdapter(simpleAdapter);
                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    MainActivity_fragment.students = list.get(position);
                                    MainActivity_fragment.sign = 1;
                                    MainActivity_fragment.setview(1);
                                }
                            });
                        }
                    });
                }
            }
        }).start();
    }

    @Override
    public void onResume() {
        super.onResume();
        setListView();
    }
}